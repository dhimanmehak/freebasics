<?php return array(

'id' => '2',

'adminname' => 'admin',

'adminemail' => 'bobancopp@gmail.com',

'dropboxemail' => '',

'dropboxpassword' => '',

'contactmail' => 'bobancopp@gmail.com',

'contactnumber' => '984561237',

'sitetitle' => 'Freebasics',

'paginationlimit' => '10',

'googleverification' => 'drt546erte5edr',

'googleanalyticscode' => '<script type=\\\"text/javascript\\\">
 var googleanalyticscode;
</script>',

'facebooklink' => 'www.facebook.com/freebasics',

'twitterlink' => 'www.twitter.com/freebasics',

'pinterestlink' => 'www.pinterest.com/freebasics',

'googlepluslink' => 'plus.google.com/freebasics',

'linkedinlink' => '',

'rsslink' => '',

'youtubelink' => 'www.youtube.com/freebasics',

'footerlogo' => 'uploads/images/footerlogo.png',

'footercontent' => 'Freebasics',

'logo' => 'uploads/images/logo.png',

'metatitle' => 'Freebasics',

'metakeyword' => 'post and back projects',

'metadescription' => 'post ur projects and earn money',

'favicon' => 'uploads/images/favicon.jpg',

'watermark' => 'uploads/images/watermark.png',

'facebookapi' => '',

'facebooksecretkey' => 'ab047a5308477527f248b287514ad68b',

'facebookaccesstoken' => '',

'paypalmode' => 'sandbox',

'paypalapiname' => 'billing@alienics.com',

'paypalapipwd' => 'UFDKCLX7VHNALYVF',

'paypalapikey' => 'AFcWxV21C7fd0v3bYYYRCpSSRl31Awzkb9OTqj.wTHEs5P1eM5wgk3zh',

'paypalid' => 'APP-80W284485P519543T',

'paypallive' => '',

'paypalclientid' => 'Afb3OmYnnxfMBXzaiXwc9uDbMKdI3OKIjKywOk12K7vpAWB_bBggaok2lR0sY0KJte6CAIaVdv1rvZy0',

'paypalsecret' => 'ECQNfI-M6uF440NS6bwRGsjh_MSQAhcwJxHPDI5hT_q1ExJn9kzR6nLgXtfvhKgSklQ_EQseeUvD8An8',

'language' => 'en',

'currency' => 'USD',

'listingfee' => '0',

'smtphost' => 'smtp.gmail.com',

'smtpport' => '465',

'smtpusername' => 'freebasics.notifications@gmail.com',

'smtppassword' => '@123123@',

'consumerkey' => 'gn24Z1tEJEU8Y8Iw6hZZ0mcIt',

'consumersecret' => 'OUoe2QsNKLCoe6UP7lqPCYT2PfcLuxO3OGRG94nPeoF4TJ7BCf',

'accesstoken' => '2258770255-NWmZl1Zm4YwLjQORvSvLTutjvkQweNuXxRTJPXi',

'accesstokensecret' => 'E7GEuDuLinrE9RJXkVfHiPAwKootTsAuQ6sxtem0qlNHa',

'googleclientsecret' => '2312q4r3rw54w4',

'googleclientid' => 'AC86dee6bbb798',

'googleredirecturl' => 'www.google.com',

'googledeveloperkey' => 'AC86dee6bbb798dfa194415808420c6518',

'facebookappid' => '441566379364333',

'liketext' => '',

'unliketext' => '',

'bannertext' => 'Post and back projects..',

'twilioaccountid' => 'AC86dee6bbb798dfa194415808420c6518',

'twilioaccounttoken' => '0a4495ba71d620a5981f0527743e5de4',

'twiliophonenumber' => '2147483647',

'googlemapapi' => 'AIzaSyC5YIg8-Yk_zqjzWpFyZrgYuzzjTCBJV7k',

'hometitle1' => 'Freebasics',

'hometitle2' => '',

'admincommission' => '10',

'affcommissiontype' => 'percentage',

'affiliatecommission' => '5',

 ); ?>