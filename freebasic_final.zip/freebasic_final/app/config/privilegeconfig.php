<?php
return array(
    'privilege' => array('User', 'Project', 'Backing', 'Category', 'Newsletter', 'Country', 'Staticpage', 'Slider', 
	'Transfer_fund', 'Contact_us', 'Account_verification','Subscription','Language','Membership','Change_request','Referral')
);
?>

