<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

define('ADMINCONFIG',  app_path().'/config/adminconfig.php');

define('NEWSLETTER', app_path().'/views/emails/newsletters');

define('STATICPAGE', app_path().'/views/mainviews/staticpages');