<?php
return array('privilege' => array('Email', 'Date_Of_Birth','Mobile','Website','Bio-Graphy'));
?>

