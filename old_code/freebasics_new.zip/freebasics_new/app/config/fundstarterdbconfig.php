<?php

if ($_SERVER['HTTP_HOST'] == "localhost:8080") {
    $host = "localhost";
    $dbname = "kickstarter_db";
    $dbusername = "root";
    $dbpassword = "";
} else {
    $host = "localhost";
    $dbname = "kickstarter_db";
    $dbusername = "root";
    $dbpassword = "";
}
