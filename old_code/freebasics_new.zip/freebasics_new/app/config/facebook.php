<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

return array(
        'appId' => '1593859854164269',
        'secret' => '5ad94c08322837753e972192411189a6'
    );